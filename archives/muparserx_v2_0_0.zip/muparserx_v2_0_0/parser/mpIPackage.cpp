#include "mpIPackage.h"

#include "mpDefines.h"
#include "mpParserBase.h"


MUP_NAMESPACE_START

//------------------------------------------------------------------------------
IPackage::IPackage()
{}

//------------------------------------------------------------------------------
IPackage::~IPackage()
{}

MUP_NAMESPACE_END